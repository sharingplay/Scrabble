#ifndef FICHA_H
#define FICHA_H


class Ficha
{
public:
    Ficha();
};

#endif // FICHA_H