//
// Created by mariana on 05/04/19.
//

#ifndef SERVER_ADJACENT_H
#define SERVER_ADJACENT_H
#include "lista.h"

class adjacent {

public:
    adjacent();
    void Seters(lista* posiciones);
};


#endif //SERVER_ADJACENT_H
