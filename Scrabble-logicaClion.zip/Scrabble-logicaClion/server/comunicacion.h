//
// Created by mariana on 05/04/19.
//

#ifndef SERVER_COMUNICACION_H
#define SERVER_COMUNICACION_H


class comunicacion {

    

public:
    comunicacion();


};


#endif //SERVER_COMUNICACION_H
