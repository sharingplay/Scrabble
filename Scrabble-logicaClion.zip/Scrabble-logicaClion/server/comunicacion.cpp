//
// Created by mariana on 05/04/19.
//

#include "comunicacion.h"

comunicacion::comunicacion() {}
