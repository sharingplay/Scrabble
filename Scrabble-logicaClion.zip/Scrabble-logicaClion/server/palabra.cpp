//
// Created by mariana on 05/04/19.
//
#include <gtest/gtest.h>
#include "palabra.h"
palabra::palabra(){}

bool palabra::verificar(nodo* final,lista* tablero){
    nodo* actual= final;
    if(actual->getDown()->getEstado()==true){
        return true;
    }
    if(!centro(tablero)){
        //no hay ficha en el centro
    }
    if(actual->getUp()->getEstado()==true){
        while (actual->getUp()->getEstado()==true) {
            actual= actual->getUp();
        }
        leerAbajo(actual);
    }
    if(actual->getLeft()->getEstado()==true){
        while (actual->getLeft()->getEstado()==true) {
            actual= actual->getLeft();
        }
        leerDerecha(actual);
    }
    if(actual->getRight()->getEstado()==true){
        return true;
    }

}
bool palabra::centro(lista* tablero){
    nodo* actual= tablero->Head;
    int i=0;
    while(i<7){
        if(actual->getRight()->getEstado()){
            return true;
        }
        else if(actual->getDown()->getEstado()){
                return true;
            }else{
            return false;
        }

        }
}
bool palabra::leerAbajo(nodo* final){
    nodo* actual= final;
    char palabra;
    while (actual->getDown()->getEstado()==true) {
        palabra+=actual->getValor()->getLetra();
        actual= actual->getDown();
    }
    //diccionario
}
bool palabra::leerDerecha(nodo* final){
    nodo* actual= final;
    char palabra;
    while (actual->getLeft()->getEstado()==true) {
        palabra+=actual->getValor()->getLetra();
        actual= actual->getLeft();
    }
    //diccionario
}
int palabra::asignarPuntuacion(nodo* final, int direccion){
    int puntuacion=0;
    int bonus=1;
    if(direccion==1){
        while (final->getDown()->getEstado()==true) {
            if(final->getPuntosAsignados()==true){
                puntuacion+=final->getValor()->getValor();
                std::cout << puntuacion << std::endl;
                final= final->getDown();
            }
            if(final->getPuntuacion()==1){
                puntuacion+=final->getValor()->getValor();
                bonus=3;
                final->setPuntosAsignados(true);
                final= final->getDown();
            }if(final->getPuntuacion()==2){
                puntuacion+=final->getValor()->getValor()*2;
                final->setPuntosAsignados(true);
                final= final->getDown();

            }if(final->getPuntuacion()==3){
                puntuacion+=final->getValor()->getValor()*3;
                final->setPuntosAsignados(true);
                final= final->getDown();

            }if(final->getPuntuacion()==4){
                puntuacion+=final->getValor()->getValor();
                bonus=2;
                final->setPuntosAsignados(true);
                final= final->getDown();
            }
        }
        puntuacion*=bonus;
        return puntuacion;
        //agregar puntuacion al jugador
    }
    if(direccion==2){
        while (final->getLeft()->getEstado()==true) {
            if(final->getPuntosAsignados()==true){
                puntuacion+=final->getValor()->getValor();
                final= final->getLeft();
            }
            if(final->getPuntuacion()==1){
                puntuacion+=final->getValor()->getValor();
                bonus=3;
                final->setPuntosAsignados(true);
                final= final->getLeft();
            }if(final->getPuntuacion()==2){
                puntuacion+=final->getValor()->getValor()*2;
                final->setPuntosAsignados(true);
                final= final->getLeft();

            }if(final->getPuntuacion()==3){
                puntuacion+=final->getValor()->getValor()*3;
                final->setPuntosAsignados(true);
                final= final->getLeft();

            }if(final->getPuntuacion()==4){
                puntuacion+=final->getValor()->getValor();
                bonus=2;
                final->setPuntosAsignados(true);
                final= final->getLeft();
            }
        }
        //agregar puntuacion al jugador
    }
}
void palabra::volverFicha(nodo *final){
    nodo* actual= final;
    if(actual->getUp()->getEstado()==true){
        while (actual->getUp()->getEstado()==true) {
            actual= actual->getUp();
        }
        quitarAbajo(actual);
    }
    if(actual->getLeft()->getEstado()==true){
        while (actual->getLeft()->getEstado()==true) {
            actual= actual->getLeft();
        }
        quitarDerecha(actual);
    }
    if(actual->getDown()->getEstado()==true){
        quitarAbajo(actual);
    }
    if(actual->getRight()->getEstado()==true){
        quitarDerecha(actual);
    }

}
void palabra::quitarAbajo(nodo* final){
    nodo* actual= final;
    while (actual!= nullptr && actual->getEstado()==true) {
        if(actual->getPuntosAsignados()==false){
            actual->getValor()->setInicialX(actual->getValor()->getInicialX());
            actual->getValor()->setInicialY(actual->getValor()->getInicialY());
            actual->setEstado(false);
            actual= actual->getDown();
        }else{
            actual=actual->getDown();

        }
    }
}
void palabra::quitarDerecha(nodo* final) {
    nodo *actual = final;
    while (actual != nullptr && actual->getEstado() == true) {
        if (actual->getPuntosAsignados() == false) {
            actual->getValor()->setInicialX(actual->getValor()->getInicialX()*50);
            actual->getValor()->setInicialY(actual->getValor()->getInicialY()*54);
            actual->setEstado(false);
            actual = actual->getRight();
        } else {
            actual = actual->getRight();
        }
    }
}


struct palabra_TEST : public testing::Test{
    palabra *test;
    void SetUp(){
        test = new palabra();
    }
    void TearDown(){
        delete test;
    }
};

TEST_F(palabra_TEST, quitarAbajo){
    nodo* A = new nodo();
    A->setEstado(true);
    A->setPuntosAsignados(false);
    ficha* uno = new ficha('A');
    A->setValor(uno);
    A->getValor()->setInicialX(57);
    A->getValor()->setInicialY(64);
    nodo* B = new nodo();
    B->setEstado(false);
    A->setDown(B);
    test->quitarAbajo(A);
    ASSERT_EQ(A->getEstado(), false);
}

TEST_F(palabra_TEST, quitarDerecha){
    nodo* A = new nodo();
    A->setEstado(true);
    A->setPuntosAsignados(false);
    ficha* uno = new ficha('A');
    A->setValor(uno);
    A->getValor()->setInicialX(57);
    A->getValor()->setInicialY(64);
    nodo* B = new nodo();
    B->setEstado(false);
    A->setRight(B);
    test->quitarDerecha(A);
    ASSERT_EQ(A->getEstado(), false);
}
TEST_F(palabra_TEST, verificar){
    lista* P = new lista();
    nodo* A = new nodo();
    nodo* B = new nodo();
    A->setDown(B);
    B->setEstado(true);
    ASSERT_EQ(test->verificar(A,P), true);
}

TEST_F(palabra_TEST, centro){
    lista* P = new lista();
    nodo* A = new nodo(); P->insertarFinal(A);
    nodo* B = new nodo(); P->insertarFinal(B);
    nodo* C = new nodo(); P->insertarFinal(C);
    A->setRight(C);
    A->setDown(B);
    B->setEstado(false);
    C->setEstado(false);
    ASSERT_EQ(test->centro(P), false);
}

TEST_F(palabra_TEST, asignarPuntuacion){
    ficha* uno = new ficha('A');
    lista* P = new lista();
    nodo* A = new nodo(); P->insertarFinal(A);
    nodo* B = new nodo(); P->insertarFinal(B);
    nodo* C = new nodo(); P->insertarFinal(C);
    A->setDown(B);
    C->setEstado(false);
    A->setValor(uno);
    A->getValor()->setValor(1);
    B->setDown(C);
    B->setEstado(true);
    A->setPuntosAsignados(true);
    std::cout << test->asignarPuntuacion(A,1) << std::endl;
    ASSERT_EQ(test->asignarPuntuacion(A,1), 1);
}



