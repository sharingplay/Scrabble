#include <iostream>
#include "Servidor.h"
#include "Servidor.cpp"
#include <gtest/gtest.h>
#include <gmock/gmock.h>

int main(int argc,char* argv[]) {

    testing::InitGoogleTest(&argc,argv);
    RUN_ALL_TESTS();

    Servidor serv (8080,1024);
    serv.runServer();

    return 0;
}