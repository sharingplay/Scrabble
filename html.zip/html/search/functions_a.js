var searchData=
[
  ['quitarabajo',['quitarAbajo',['../classpalabra.html#a3c15e88d097f0c4b4fa3cff27ff4657d',1,'palabra']]]
];
