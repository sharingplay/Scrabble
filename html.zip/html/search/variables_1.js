var searchData=
[
  ['posiciones',['posiciones',['../classtablero.html#a9882d7c4c2cc9874b0019fc4bef1d82a',1,'tablero']]]
];
