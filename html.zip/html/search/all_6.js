var searchData=
[
  ['generar',['generar',['../classtablero.html#a64d1e02dccc0c2fa49d7bc6c703f69cd',1,'tablero']]],
  ['getcentro',['getcentro',['../classtablero.html#aa63f2dd68db443c16b1316daec72d546',1,'tablero']]]
];
