var searchData=
[
  ['verificar',['verificar',['../classpalabra.html#a341db5df982bac15a39ed5d0b7b0351c',1,'palabra']]],
  ['volverficha',['volverFicha',['../classpalabra.html#a02db0894b649794d256d13e4be5f8dcf',1,'palabra']]]
];
