var searchData=
[
  ['qt_5fmeta_5fstringdata_5fficha_5ft',['qt_meta_stringdata_ficha_t',['../structqt__meta__stringdata__ficha__t.html',1,'']]],
  ['qt_5fmeta_5fstringdata_5ftablero_5ft',['qt_meta_stringdata_tablero_t',['../structqt__meta__stringdata__tablero__t.html',1,'']]],
  ['quitarabajo',['quitarAbajo',['../classpalabra.html#a3c15e88d097f0c4b4fa3cff27ff4657d',1,'palabra']]]
];
