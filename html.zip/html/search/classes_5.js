var searchData=
[
  ['lector',['lector',['../classlector.html',1,'']]],
  ['lista',['lista',['../classlista.html',1,'']]]
];
