var searchData=
[
  ['eliminar',['eliminar',['../classjugador.html#a1174400e7d5226eb0a08ce7e4476d100',1,'jugador']]]
];
