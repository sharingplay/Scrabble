var searchData=
[
  ['ventanacomodin',['ventanaComodin',['../classventana_comodin.html',1,'']]],
  ['ventanaconfirmar',['ventanaConfirmar',['../classventana_confirmar.html',1,'']]],
  ['ventanafinpartida',['ventanaFinPartida',['../classventana_fin_partida.html',1,'']]],
  ['ventanapuntuacion',['ventanaPuntuacion',['../classventana_puntuacion.html',1,'']]],
  ['ventanavalidar',['ventanaValidar',['../classventana_validar.html',1,'']]]
];
