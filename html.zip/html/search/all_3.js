var searchData=
[
  ['dibujar',['dibujar',['../classficha.html#a81df3e0a28b8e78e730179e436aa7abc',1,'ficha']]]
];
