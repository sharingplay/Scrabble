var searchData=
[
  ['palabra',['palabra',['../classpalabra.html',1,'']]]
];
