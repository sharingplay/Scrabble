var searchData=
[
  ['jugador',['jugador',['../classjugador.html',1,'']]]
];
