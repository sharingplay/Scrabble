var searchData=
[
  ['cliente',['cliente',['../classcliente.html',1,'']]],
  ['comodin',['comodin',['../classcomodin.html',1,'']]]
];
