var searchData=
[
  ['valor',['valor',['../classcomodin.html#a7dd3121f5a5ac2de8f61d579323403c1',1,'comodin']]]
];
