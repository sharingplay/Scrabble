var searchData=
[
  ['leer',['leer',['../classlector.html#add34c3ce5037cac5acae35b40cb3fdb0',1,'lector']]],
  ['leerabajo',['leerAbajo',['../classpalabra.html#a2b4fa31dd1d1261a01a8104ae46ccec2',1,'palabra']]],
  ['leerderecha',['leerDerecha',['../classpalabra.html#a32656ee63d1289cf279b8fcc272bcea5',1,'palabra']]]
];
