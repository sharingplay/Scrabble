var searchData=
[
  ['acomodar',['acomodar',['../classtablero.html#af132946e4a2a62e551b29f06cf013e0d',1,'tablero']]],
  ['adjacent',['adjacent',['../classadjacent.html',1,'']]],
  ['adyacente',['Adyacente',['../class_adyacente.html',1,'']]],
  ['agregarficha',['agregarFicha',['../classjugador.html#ad16260b11912abcc919ac68d5af69d20',1,'jugador']]]
];
