var searchData=
[
  ['ficha',['ficha',['../classficha.html',1,'ficha'],['../classficha.html#a3dac97fe7c6a19c49f030ff94669c318',1,'ficha::ficha()']]]
];
