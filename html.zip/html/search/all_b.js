var searchData=
[
  ['palabra',['palabra',['../classpalabra.html',1,'']]],
  ['posiciones',['posiciones',['../classtablero.html#a9882d7c4c2cc9874b0019fc4bef1d82a',1,'tablero']]],
  ['puntuacion',['Puntuacion',['../classtablero.html#ac1ec66c512b311a750ca15864a9d4951',1,'tablero']]]
];
