var searchData=
[
  ['repartir',['repartir',['../classbolsa.html#a2c302fa2ba6f29315a3c690608a3a2ca',1,'bolsa']]]
];
