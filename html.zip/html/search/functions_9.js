var searchData=
[
  ['puntuacion',['Puntuacion',['../classtablero.html#ac1ec66c512b311a750ca15864a9d4951',1,'tablero']]]
];
