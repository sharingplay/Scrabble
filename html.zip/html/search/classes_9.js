var searchData=
[
  ['qt_5fmeta_5fstringdata_5fficha_5ft',['qt_meta_stringdata_ficha_t',['../structqt__meta__stringdata__ficha__t.html',1,'']]],
  ['qt_5fmeta_5fstringdata_5ftablero_5ft',['qt_meta_stringdata_tablero_t',['../structqt__meta__stringdata__tablero__t.html',1,'']]]
];
