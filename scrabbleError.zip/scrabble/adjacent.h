#ifndef ADJACENT_H
#define ADJACENT_H
#include "lista.h"
class adjacent
{
public:
    adjacent();
    void Seters(lista* posiciones);
};

#endif // ADJACENT_H
