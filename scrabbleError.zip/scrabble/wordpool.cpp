#include "wordpool.h"

WordPool::WordPool()
{

}
