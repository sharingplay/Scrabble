#ifndef ADYACENTE_H
#define ADYACENTE_H


class Adyacente
{
public:
    Adyacente();
};

#endif // ADYACENTE_H
