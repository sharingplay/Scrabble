#ifndef ADJACENT_H
#define ADJACENT_H
#include "lista.h"

class adjacent
{
public:
    adjacent();
    void Seters(lista toset);
};

#endif // ADJACENT_H
