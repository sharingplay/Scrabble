#ifndef WORDPOOL_H
#define WORDPOOL_H
#include "ficha.h"

class WordPool
{
private:
    int cantLetras;
public:
    WordPool();

};

#endif // WORDPOOL_H
